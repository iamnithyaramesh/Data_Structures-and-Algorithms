# -*- coding: utf-8 -*-
"""
This module provides a Python program reads “words.txt” and 
“words-histogram.txt” files and does the following until
'EOFError' is raised:
 Reads input text 'prefix' from the console and prints
 all the words that start with that 'prefix'. The output
 words should be in the descending order of their appearance
 count. Your program should continue to do this until
'EOFError' is raised (which can be achieved by pressing ctrl-D).

This is a sample implementation and may contain bugs!
We have tried to follow good coding practices but don't
claim that this source code is perfect!

Your comments and suggestions are welcome.

Created on Tue Apr 11 2023

Revised on Wed Apr 19 2023

Original Author:R.Nithyasri(IT-B)[Reg No:3122 22 5002 086]
"""

#Driver Code

''' The program reads in two text files 'words.txt' and
'words-histogram.txt to read till EOF and print the words
that start with the word 'prefix' in the decreasing order of 
their appearance count'''


file_1=open('words.txt','r')
file_2=open('words-histogram.txt','r')
word='prefix'
try:
        d={}
        data_1=file_1.readlines()
        data_2=file_2.readlines()
        l=[]
        for i in data_1:
              l1=i.split(' ')
              l1.pop()
              for j in l1:
                    l.append(j)
        for i in data_2:
              l1=i.split(' ')
              l1.pop()
              for j in l1:
                    l.append(j)
        for w in l:
                if w.startswith(word):
                    if w not in d:
                          d[w]=1
                    else:
                          d[w]=d[w]+1                 
        x1={k:v for k,v in sorted(d.items(),reverse=True,key=lambda item:item[1])}
        print(x1)

except  EOFError:       
   pass

''' Use of try - except exception block to handle the EOFError,
if raised by passing on the next executing of the code'''
        


    

