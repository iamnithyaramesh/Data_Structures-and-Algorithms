# -*- coding: utf-8 -*-
"""
This module provides a Python program that reads 
all the given text files and perform the following:
Prepares the set of words appearing in the given text files 
and stores them as “words.txt” andPrepares a bag of words that
records how many times each word is appearing in the 
given text files and stores them as “words-histogram.txt”.
This is a part of PSP Exercise 01 under UIT2201 
(Programming and Data Structures-("Software Development Lab"))


This is a sample implementation and may contain bugs!
We have tried to follow good coding practices but don't
claim that this source code is perfect!

Your comments and suggestions are welcome.

Created on Tue Apr 11 2023

Revised on Mon Apr 17 2023

Original Author:R.Nithyasri(IT-B)[Reg No:3122 22 5002 086]

"""
#Driver Code


import os

""" This part of the program provides a method to read all the files within
a root directory -(The root directory used here C:/Users/ nithy/Desktop)
and write the words present in all the text files into a file named words.txt"""

if __name__ == "__main__":
    for (root,dirs,files) in os.walk('.', topdown=True):  #os.walk()to browse through the sub-directories 
        for file in files:                                #and files within a root directory
            if file[-4:]==".txt":
                with open(file,'r') as source:
                    with open('words.txt','a') as destination:
                        data=source.read()
                        text=data.split(' ')
                        print(text)
                        for word in text:
                            print(word)
                            destination.write(word) 
                            destination.write(' ')   

           
    '''This part of the program  reads the contents of 'words.txt' and 
     determine the frequency count of each word and write each word
      and its corresponding frequency count into a text file named
       words-histogram.txt '''   


    frequency_histogram={}
    with open('words.txt','r') as text:
        t=text.read()
        content=t.split(' ')
        for word in content:
            if word not in frequency_histogram:
                frequency_histogram[word]=1
            else:
                frequency_histogram[word]=frequency_histogram[word]+1
    with open('words-histogram.txt','w') as histogram:
        for i in frequency_histogram:
            histogram.write(i+'   '+str(frequency_histogram[i]))
            histogram.write('\n')
    




