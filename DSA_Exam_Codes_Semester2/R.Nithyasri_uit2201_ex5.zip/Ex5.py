# -*- coding: utf-8 -*-
"""
This module provides a Python program to execute BubbleSort,SelectionSort
and InsertionSort to a sequence of elements and analyze its time complexity.
This is a part of Exercise 05 under UIT2201 (Programming and Data Structures).


This is a sample implementation and may contain bugs!
We have tried to follow good coding practices but don't
claim that this source code is perfect!

Your comments and suggestions are welcome.

Created on Tue Apr 11 2023

Revised on Wed 10 May 2023

Original Author:R.Nithyasri(IT-B)[Reg No:3122 22 5002 086]

"""

import time
import math

# Functions definitions required:

#1 This is the function random_sequence_generator

def random_sequence_generator(n,start,end):

    ''' Arguments required:
    
    n       - number of elements in the sequence
    start   - start range of the element value
    end     -end range of the element value
    
    Returns:
     A sequence with 'n' random elements within the range(start,end)'''
    
    import random
    seq=[]
    for i in range(n):
        seq.append(random.randint(start,end))
    return seq

# End of the function 'random-sequence-generator

#2 This is the function 'bubble-sort'

def bubble_sort(seq):

    ''' Arguments Taken: 
                        a sequence of elements
    
    The functions performs a bubble sort on the input sequence
    
    Returns:
                        a sequence of sorted elements(sort performed through BubbleSort method)
                        number of comparisons made  -"comparisons"
                        number of swappings done    -"swappings"'''
    
    
    n=len(seq)
    no_of_comparisons=0
    swappings=0
    for i in range(n):
        for j in range(n-i-1):
            no_of_comparisons+=1
            if seq[j]>seq[j+1]:
                swappings+=1
                seq[j],seq[j+1]=seq[j+1],seq[j]
    return seq,no_of_comparisons,swappings

# End of the function 'bubble_sort()'

# 3 This is the function selection_sort(seq)

def selection_sort(seq):

    ''' Arguments Taken: 
                        a sequence of elements
    
    The functions performs a selection sort on the input sequence
    
    Returns:
                        a sequence of sorted elements(sort performed through SelectionSort method)
                        number of comparisons made  -"comparisons"
                        number of swappings done    -"swappings1"'''
    n=len(seq)
    no_of_comparisons=0
    swappings1=0
    for i in range(n):
        for j in range(i+1,n):
            no_of_comparisons+=1
            if seq[i]>seq[j]:
                swappings1+=1
                seq[i],seq[j]=seq[j],seq[i]
    return seq,no_of_comparisons,swappings1

# End of the function 'selection_sort()'

# 4 This is the function 'insertion_sort()'

def insertion_sort(seq):

    ''' Arguments Taken: 
                        a sequence of elements
    
    The functions performs an insertion sort on the input sequence
    
    Returns:
                        a sequence of sorted elements(sort performed through Insertion Sort method)
                        number of comparisons made "comparisons"
                        number of swappings done "swappings2"'''
    n=len(seq)
    comparisons=0
    swappings=0
    for i in range(1,n):
        comparisons+=1
        temp=seq[i]
        j=i-1
        while j>=0 and temp<seq[j]:
            seq[j+1]=seq[j]
            comparisons+=1
            j=j-1
            seq[j+1]=temp
    return seq,comparisons,swappings

# End of the function insertion_sort()

    
# Driver Code

''' Appropriate Testcases are to be given to check the validity of the code'''

n=int(input('No of Terms'))
start=int(input('Start Index'))
end=int(input('End Index'))

# Generating a random sequence of elements 

l=random_sequence_generator(n,start,end)
l1=l[::-1][::-1]
l2=l[::-1][::-1]

# Performing Empirical Analysis on the values

# BubbleSort Method

bs_t_start=time.time()
op_b=bubble_sort(l)
print(op_b)
print(op_b[1])
print(op_b[2])
print(op_b[2]/n)
print(op_b[2]/n**2)
print(op_b[2]/n**3)
print(op_b[2]/n*math.log2(n))
bs_t_end=time.time()
print("Bubble Sort Time:",bs_t_end-bs_t_start)

#Selection Sort Method

ss_t_start=time.time()
op_s=selection_sort(l1)
print(op_s)
print(op_s[1])
print(op_s[2]/n)
print(op_s[2]/n**2)
print(op_s[2]/n**3)
print(op_s[2]/n*math.log2(n))
ss_t_end=time.time()
print("Selection Sort Time:",ss_t_end-ss_t_start)

# Insertion Sort Method

is_t_start=time.time()
op_i=insertion_sort(l2)
print(op_i)
print(op_i[1])
print(op_i[2]/n)
print(op_i[2]/n**2)
print(op_i[2]/n**3)
print(op_i[2]/n*math.log2(n))
is_t_end=time.time()
print("Insertion Sort Time:",is_t_end-is_t_start)


