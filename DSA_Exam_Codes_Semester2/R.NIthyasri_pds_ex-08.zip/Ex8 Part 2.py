# -*- coding: utf-8 -*-
"""
This module provides a ListADT with "extend())",
"contains()","index()" and "count()" functionalities.


This is a sample implementation and may contain bugs!
We have tried to follow good coding practices but don't
claim that this source code is perfect!

Your comments and suggestions are welcome.

Created on Wed May 18 2023

Revised on Tue May 30 2023

Original Author:R.Nithyasri(IT-B)[Reg No:3122 22 5002 086]
"""
# Importing the required modules for execution

import ctypes
import sys
import time
import random

class ListADT():
    
    ''' Performs the implementation of a list.

    Data Members: self and val

    Member Functions :
                       makearray()
                       resize()
                       extend()
                       __contains__()
                       index()
                       count()
    '''

    # 1 This is the constuctor of the class Product

    def __init__(self,val):

        '''Assigning of data members'''

        if isinstance(val,int):          #For a single element list
            self.n=0
            self.capacity=1
            self.A=[]                    #Allocation of memory
        else:
            self.n=len(val)-1            #For a multiple element list
            self.A=val
            self.capacity=len(val)

     # End of the constructor

     #-------------------------------------------------------------------------------

    # Member Functions:

    # 1 This is the function make_array()
    def make_array(self,cap):

        ''' Creates an Dynamic Array with the required capacity using the ctypes module'''

        self.capacity=cap
        dy_list=(cap*ctypes.py_object)()
        return dy_list
    
    # End of the function makearray()

    # 2 This is the function resize()
    def resize(self,cap):

        ''' Resizes the capacity of the Dynamic Array with the  required capacity'''

        B=self.make_array(cap)
        for index in range(self.n):
            B[index]=self.A[index]
        self.A=B
        self.capacity=cap
    
    # End of function resize()
    
    #3 This is the function 'extend'
    def extend(self,list):

        '''Performs the extend function on a list
        
        Resizes the Dynamic Array in case of sufficient capacity and
        appends the elements of another list object into the self object'''

        if self.n==self.capacity:
            self.resize(2*self.capacity)
        for i in list:
            self.A[self.n]=i
            self.n+=1
    
    # End of function 'extend'

    #4 This is the function '__contains__'
    def __contains__(self,element):

        ''' Checks whether an element is present in a list object , returns
        True if element is present in a list,else False'''

        for index in range(self.n):
            if self.A[index]==element:
                return True
            else:
                return False
    
    # End of the function __contains__

    #5 This is the function 'index()'
    def index(self,element):

        ''' Checks whether an element is present in a list object , returns
        the index of the element if found ,else return False '''

        l=[]
        for index in range(self.n):
            if self.A[index]==element and (element not in l):
                return index
            else:
                return -1
            
    # End of the function index()

    #6 This is the function 'count()'
    def count(self,element):

        '''Counts the number of occurences of an element in a list
        and returns the count value'''

        count_variable=0
        for index in range(self.n):
            if self.A[index]==element:
                count_variable+=1
        return count_variable
    
    # End of the function 'count()'
    
    def __str__(self):
        
        ''' The __str__()function is over-rided to 
        define the print() statement for the objects
        of the ADT'''

        return str(self.A)

    def __len__(self):

        ''' The __len__() function is over-rided to 
        facilitate iterative operations on the ADT'''

        return len(self.A)
    
    def __getitem__(self,index):

        '''The __getitem__() function is over_rided
        to return the value corresponding to an index'''

        return self.A[index]
    
    def __setitem__(self,index,value):

        '''The __setitem__() function is over_rided
        to fix a value to an index'''

        self.A[index]=value

# This is the end of the class ListADT

# Driver Code

''' Appropriate test cases are to be given to
check the validity of the code'''

L1=ListADT([1,2,3])
L2=[2,3,4]
L1.extend(L2)
print(L1)
print(L1.__contains__(2))
print(L1.index(3))
print(L1.count(4))






