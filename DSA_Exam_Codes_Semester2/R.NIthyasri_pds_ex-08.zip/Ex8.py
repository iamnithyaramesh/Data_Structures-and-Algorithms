# -*- coding: utf-8 -*-
"""
This module provides a ListADT with "append()",
"insert()" and "delete()" functionalities.

Additional functionalities include ovveriding the
__str__() , __len__() , __getitem__(), __setitem__().

This is a sample implementation and may contain bugs!
We have tried to follow good coding practices but don't
claim that this source code is perfect!

Your comments and suggestions are welcome.

Created on Wed May 18 2023

Revised on Tue May 30 2023

Original Author:R.Nithyasri(IT-B)[Reg No:3122 22 5002 086]
"""
# Importing the required modules for execution

import ctypes
import sys
import time
import random

# This is the class "ListADT"
 
class ListADT:

    ''' Performs the implementation of a list.

    Data Members: self and val

    Member Functions :
                       makearray()
                       resize()
                       append()
                       insert()
                       delete()
                       __str__()
                       __len__()
                       __setitem__()
                       __getitem__()
    '''

    # 1 This is the constuctor of the class Product

    def __init__(self,val):

        '''Assigning of data members'''

        if isinstance(val,int):          #For a single element list
            self.n=0
            self.capacity=1
            self.A=[]                    #Allocation of memory
        else:
            self.n=len(val)-1            #For a multiple element list
            self.A=val
            self.capacity=len(val)

     # End of the constructor

     #-------------------------------------------------------------------------------

    # Member Functions:

    # 1 This is the function make_array()
    def make_array(self,cap):

        ''' Creates an Dynamic Array with the required capacity using the ctypes module'''

        self.capacity=cap
        dy_list=(cap*ctypes.py_object)()
        return dy_list
    
    # End of the function makearray()

    # 2 This is the function resize()
    def resize(self,cap):

        ''' Resizes the capacity of the Dynamic Array with the  required capacity'''

        B=self.make_array(cap)
        for index in range(self.n):
            B[index]=self.A[index]
        self.A=B
        self.capacity=cap
    
    # End of function resize()

    # 3 This is the function append()
    
    def append(self,val):

        '''Performs the append function on a list
        
        Resizes the Dynamic Array in case of sufficient capacity and
        assigns the elements to the corresponding indices at the end of the list'''

        if self.n<self.capacity:
            self.A[self.n]=val
            self.n=self.n+1
        else:
            self.resize(2*self.capacity)
    
    # End of the function append()

    # 4 This is the function insert()

    def insert(self,element,index):

        '''Performs the insert function on a list
        
        Resizes the Dynamic Array in case of sufficient capacity and
        assigns the elements to the specific index position'''

        try:
            if 0<=index<=self.n:
                if self.n==self.capacity:
                    self.resize(2*self.capacity)
                while self.n>index:
                    self.A[self.n]=self.A[self.n-1]
                    self.n-=1
                self.A[self.n]=element
                self.n+=1
        except IndexError:
            raise IndexError
    
    # End of the function insert()

    # 5 This is the function delete()

    def delete(self,index):

        '''Performs the delete function on a list
        
        Resizes the Dynamic Array in case of excess capacity-
         (number of elements less than 25% of the capacity) and
        deletes the element at the specific index position'''

        try:
            if 0<=index<=self.n:
                for i in range(index,self.n):
                    self.A[i]=self.A[i+1]
                self.n-=1
                if self.n<self.capacity//4:
                    self.resize(self.capacity//2)
        except IndexError:
            raise IndexError
    
    # End of the function delete()

    def __str__(self):
        
        ''' The __str__()function is over-rided to 
        define the print() statement for the objects
        of the ADT'''

        return str(self.A)

    def __len__(self):

        ''' The __len__() function is over-rided to 
        facilitate iterative operations on the ADT'''

        return len(self.A)
    
    def __getitem__(self,index):

        '''The __getitem__() function is over_rided
        to return the value corresponding to an index'''

        return self.A[index]
    
    def __setitem__(self,index,value):

        '''The __setitem__() function is over_rided
        to fix a value to an index'''

        self.A[index]=value
    
# This is the end of the class ListADT

# Driver Code

''' Appropriate test cases are to be given to
check the validity of the code'''


L1=ListADT([1,2,3])
print(L1)

start_time=time.time()
n=int(input('Enter no of elements'))
for i in range(n):
    value=input(random.randint(1,100))
    L1.append(value)
end_time=time.time()
time_diff=end_time-start_time
print(time_diff)

L1.insert(1,3)
L1.delete(1)
print(L1)

        


