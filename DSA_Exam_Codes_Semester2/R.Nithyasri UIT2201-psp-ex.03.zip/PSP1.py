# -*- coding: utf-8 -*-
"""
This module provides a Python program to read a CSV file and perform linear
regression analysis of the data.This is a part of PSP Exercise 01 under UIT2201 
(Programming and Data Structures-("Software Development Lab"))


This is a sample implementation and may contain bugs!
We have tried to follow good coding practices but don't
claim that this source code is perfect!

Your comments and suggestions are welcome.

Created on Tue Apr 11 2023

Revised on Sun May 06 2023

Original Author:R.Nithyasri(IT-B)[Reg No:3122 22 5002 086]"""


# This is the function linear_regression()
def linear_regression(data,index_1,index_2):

        ''' Input: The data sequence of a CSV file(data),
                Two index values - index_1,index_2
        
            The function performs linear regression 
            on the values mentioned the fields with 
            index_1 and index_2 of the data extracted 
            from the CSV file
            
        Returns: The regression parameters,beta_0,beta_1'''
    
        l1=[]
        l2=[]
        for i in data:
            j=i.split(',')
            l1.append(float(j[index_1]))        # Appending the required values to separate lists
            l2.append(float(j[index_2]))

        # Calculation of the numerator term

        nr_t1=0
        for x in l1:
            for y in l2:
                if l1.index(x)==l2.index(y):
                    nr_t1+=(x*y)
        x_avg=sum(l1)/len(l1)
        y_avg=sum(l2)/len(l2)
        nr_t2=len(l1)*(x_avg*y_avg)
        nr=nr_t1-nr_t2
        
        # Calculation of the denominator term

        dr_t1=0
        dr_t2=0
        for i in l1:
            dr_t1+=(i)**2
        dr_t2=len(l1)*((x_avg)**2)
        dr=dr_t1-dr_t2

        # Calculation of the regression parameter by division of the numerator by the denominator

        beta_1=nr/dr

        # Substituting beta_1 in the mentioned formula

        beta_0=y_avg-(beta_1*(x_avg))

        return beta_0,beta_1


# Driver Code

''' Appropriate Testcases are to be given to check the validity of the code'''

with open("PSP1.csv",'r') as file:
    source_data=file.readlines()
    
    # User Defined Menu

    print("Enter 1 for x: estimated proxy size; y: actual LOC (added+modified)\n Enter 2  x: estimated proxy size; y: actual time taken\n Enter 3 x: planned LOC (added+modified); y: actual LOC (added+modified)\n Enter 4 for x: planned LOC (added+modified); y: actual time taken")
    choice=int(input("Enter 1/2/3/4"))
    if choice==1:
         print(linear_regression(source_data,1,3))
    elif choice==2:
         print(linear_regression(source_data,1,4))
    elif choice==3:
         print(linear_regression(source_data,2,3))
    elif choice==1:
         print(linear_regression(source_data,2,4))
    else:
         print("Invalid")
 

        
    
            
      
            
        
        