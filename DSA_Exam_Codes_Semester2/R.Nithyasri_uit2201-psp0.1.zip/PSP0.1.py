 #-*- coding: utf-8 -*-
'''
This module provides a python program that reads all the Python
source code files from a Python package and reports the Lines
of Code(LOC) -{IGNORING COMMENTS AND DOCSTRINGS}

along with 

Total code size (Total LOC of the package)

• Number of modules and total size of each module (sub-directory)

• Number of sub-modules under each module (Each file under the sub-directory) and total size of
each sub-module

• Number of independent functions (defined outside a class) in each sub-module and total size of
each function

• Number of classes in each sub-module and total size of each class

• Number of methods (functions defined within a class) in each class and total size of each method

• Total size of other lines of code in each sub-module


This is a part of the exercises given under the course UIT2201 
    (Programming and Data Structures).

This is a sample implementation and may contain bugs!

Your comments and suggestions are welcome.

Created on Wed Apr 18 2023

Revised on Wed Apr 18 2023

Original Author: R.Nithyasri[IT-B] Reg.No 3122 22 5002 086
'''

# Functions to be used for execution

#1 This is the function LOC(data):

def LOC(data):

    ''' The function takes in a sequence of lines in a python source
    code file as input and returns the lines of code in the file
    excluding any comments and docstrings'''

    lines_of_code=0    #Initialization of counter variable

    for i in data:
        line=i.rstrip().lstrip()
        flag=True
        if line.startswith('#'):    # Flag Reversal Method to tackle with docstrings and comments
            flag=False
        elif  line.startswith("'''") or line.startswith('"""'):
            flag=False
            if line.endswith("'''") or line.endswith('"""'):
                flag=True
           
        if flag==True:
                lines_of_code+=1
    return lines_of_code

# End of function LOC(data)

# 2 This is the function classcount(data)
def classcount(data):
     
    ''' The function takes in a sequence of codelines from
      a Python source code file  as input and returns the 
      no of classes in the Python file '''
    
    classcount=0     #Initialization of counter variable

    for i in data:
        line=i.rstrip().lstrip()
        if line.startswith('class'):    # A class starts with the keyword "class"!
            classcount+=1
    return classcount

# End of the function classcount(data)

#3 This is the function function_count(data

def function_count(data):

    ''' The function takes in a sequence of lines of a Python source
     code file and calculates the no of classes in the file '''
    
    fn_count=0  #Initialization of counter variable

    for i in data:
        line=i.rstrip().lstrip()
        if line.startswith('def'):  # A function starts with the keyword 'def'
            fn_count+=1

    return fn_count

#End of the function function_count(data)


# 4 This is the fucntion module_count(data)

def module_count(data):

    ''' The function takes in a sequence of codelines within a
    Python source code file to return the number of modules
    in the python  file'''

    module_count=0  #Initialization of counter variable

    for i in data:
        line=i.rstrip().lstrip()
        if line.startswith('import'):   #A module call starts with the keyword 'import'
            module_count+=1

    return module_count

# End of function module_count(data)

#5 This is the function lines_of_classes(data)

def lines_of_classes(data):

        ''' The function takes in a sequence of lines from a Python code file
            and returns the number of codelines within classes in the Python file'''
        
        class_line=0    #Initializing the count variable

        for line in data:
            if line.startswith('class'):        # Checking condition for classes
                class_line+=1
                for i in range(data.index(line),len(data)):
                    if (data[i].ljust(0))!=data[i]:             # The lines within a class and indented!
                        class_line+=1
                    else:
                        break

        return class_line 
 
 # End of the function lines_of_classes

 # 6 This is the function fn_within_classes(data)
def fn_within_classes(data):
        
        ''' The function takes in a sequence of lines from a Python
        source code file and returns the number of functions within classes
        (number of methods) and size of functions'''

        fn_line=0       #Initialization of counter variables
        fn_count=0

        for line in data:
            if line.startswith('class'):            # Check condition for classes!
                for j in data:
                    if j.startswith('def'):         # Check condition for functions!
                        fn_count+=1
                        for k in range(data.index(j),len(data)):
                            if data[k].ljust(0)!=data[k]:           #INDENTATION CHECK - Left aligning!
                                fn_line+=1
                            else:
                                 break
        return "Function Count:",fn_count,"Lines of function",fn_line 
 
# End of function fn_within_classes(data)


#---------------------------------------------------------------------------------------------------------


# Driver Code


import os
sub_dir_count=0

if __name__ == "__main__":
    Total_lines_of_code=0
    sub_module_line_count=0

    import zipfile                  # Importing zipfile module to access the zip file 'xml.zip'

    for (root,dirs,files) in os.walk('.', topdown=True):        

        ''' Traversing through the root directory { Path of the root directory :","C:\Users\nithy\OneDrive\Desktop"}'''

        for file in files:

            if file=='xml.zip':                       # Accessing the zipfile
                content= zipfile.ZipFile(file)        # Use of ZipFile method and namelist method of the zipfile module
                list_of_files=content.namelist()   

                for file in list_of_files:
                    if (file.endswith(".py"))==False:
                        sub_module_line_count=0
                        sub_dir_count+=1                # Count of sub_directories
                        print("\n")
                        print("Files within",file)

                        if file.endswith(".py"):
                         with open(file,'r') as source:
                                data=source.readlines()

                    file_count=0
                    if file.endswith(".py"):
                        file_count+=1                    # Count of files within a sub-directory
                        with open(file,'r') as source:
                                data=source.readlines()
                                sub_module_line_count+=LOC(data)

                                # Outputs required

                                print(file,"Lines Of Code:",LOC(data))
                                print(file,"Class Count",classcount(data))
                                print(file,"Function Count",function_count(data))
                                print(file,"Module Count",module_count(data))
                                print(file,"Lines of code within classes",lines_of_classes(data))
                                print(file,"Lines of code within functions",fn_within_classes(data))
                                Total_lines_of_code=Total_lines_of_code+LOC(data)+lines_of_classes(data)+fn_within_classes(data)[1]
                                print('\n')
                    print("Lines within SubModule",sub_module_line_count)

    print("----------------------------------------------")
    print("Total Lines in the package",Total_lines_of_code)     # Total Lines of package =Sum of all the lines of code
    print("Total Number of sub_directories",sub_dir_count)

    





                       


        
        
