# -*- coding: utf-8 -*-
"""
This module provides a function norm(v, p) that
returns p-norm of a given vector a function norm(v)  
that returns the Euclidean norm of v.
This is the problem 3 under part B of  Exercise 1 given under
the course UIT2201 (Programming and Data Structures).

This is a sample implementation and may contain bugs!
We have tried to follow good coding practices but don't
claim that this source code is perfect!

Your comments and suggestions are welcome.

Created on Wed Apr 05 2023

Revised on Mon Apr 10 2023

Original Author: R.Nithyasri(IT-B)[3122 22 5002 086]"""


# This is the function norm(v,p)

''' The function returns the p-norm value of a given vector sequence v

Input Format: A vector sequence in the form of a tuple v
              p-value - the power to be taken into consideration
              
Returns     : The p-norm value of the given vector sequence v

'''
def norm(v,p):
        sum=0
        n=len(v)
        for i in range(n):
            sum+=v[i]**p
            f=1/p
            root=sum**f
        return root

# End of function norm(v,p)

# This is the function eu_norm(v)

'''The function returns the Euclidean norm value of a given 
    vector sequence v

Input Format: A vector sequence in the form of a tuple v
              p-value - To calculate the Euclidean Norm,
                        the p-value is set to 2
              
Returns     : The Euclidean norm value of the given vector sequence v'''

def eu_norm(v):
      sum=0
      n=len(v)
      for i in range(n):
        sum+=v[i]**2
        root=sum**0.5
      return root

# End of function eu_norm(v)

# The main program 

""" Giving appropriate testcases to check the validity
of the function"""

if __name__ == '__main__':
    print(norm((2.5,4.5,1.34),3))
    print(norm((2.89,5.67,1.11,9.08,3.45),2))
    v=eval(input("Enter a tuple representing vector distances"))
    p=int(input("Enter power"))
    if p==2:
        print("Euclidean norm of the vector",eu_norm(v))
    else:
        print("p-norm value",norm(v,p))
    
