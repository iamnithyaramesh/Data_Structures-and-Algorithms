# -*- coding: utf-8 -*-
"""
This module provides a function that takes in three integers, 
a, b, and c, from the console and returns  
if they can be used in “a + b = c”, “a = b − c”, or “a ∗ b = c”.
This is the code of problem 1 of part A of the exercise 1 given
 under the course (Programming and Data Structures).

This is a sample implementation and may contain bugs!
We have tried to follow good coding practices but don't
claim that this source code is perfect!

Your comments and suggestions are welcome.

Created on Wed Apr 05 2023

Revised on Sat Apr 08 2023

Original Author:R.Nithyasri(IT-B)[Reg No:3122 22 5002 086]
"""


def condition1(val1,val2,val3):
    """Finds if the sum of any two numbers of the given 
    three integers is equal to the other one using comparison 
    operators.

       Input: Three integers 'val1','val2','val3'.
       
       Returns:True ,if either a+b=c or b+c=a or c+a=b 
       is valid for the given three integers. """
    
    if val1+val2==val3:
        return True
    elif val2+val3==val1:
        return True
    elif val3+val1==val2:
        return True

# End of the function condition1(val1,val2,cal3)


def condition2(val1,val2,val3):
    """Finds if the difference of any two numbers of the given 
    three integers is equal to the other one using comparison 
    operators.

       Input: Three integers 'val1','val2','val3'.
       
       Returns:True ,if either a=b-c or b=c-a or c=a-b 
       is valid for the given three integers. """

    if val1==val2-val3:
        return True
    elif val2==val3-val1:
        return True
    elif val3==val1-val2:
        return True
    
# End of the function condition2(val1,val2,val3)


def condition3(val1,val2,val3):
    """Finds if the product of any two numbers of the given 
    three integers is equal to the other one using comparison 
    operators.

       Input: Three integers 'val1','val2','val3'.
       
       Returns:True ,if either a*b=c or b*c=a or c*a=b 
       is valid for the given three integers. """
    
    if val1*val2==val3:
        return True
    elif val2*val3==val1:
        return True
    elif val3*val1==val2:
        return True

# End of function condition3(val1,val2,val3)



# This is the main driver code.

""" Input Format : Three integer values a,b,c, if either of these 
                   is empty, then the program raises an exception 
                   for insufficient values.

    The function checks the validity of a,b,c to the mentioned
    conditions by implementing the functions condition1(),
    condition2() and condition3().

    Returns: The conditions satisfied by the three integers."""
            
  
a=int(input("Enter FIRST INTEGER"))
b=int(input("Enter SECOND INTEGER"))
c=int(input("Enter THIRD INTEGER"))
print("\nThe Output of the program:")

if a=='' or b=='' or c=='':
        print('Insufficient values!! Error!!!')
else:
        if condition1(a,b,c)==True:
            print("The arithmetic operation of the form 'a+b=c' is TRUE")
        if condition2(a,b,c)==True:
            print("The arithmetic operation of the form 'a=b-c' is TRUE")
        if condition3(a,b,c)==True:
            print("The arithmetic operation of the form 'a*b=c' is TRUE")
        if (condition1(a,b,c) and condition2(a,b,c) and condition3(a,b,c))==False:
            print("The three integers satisfy NONE of the arithmetic operations")


        

