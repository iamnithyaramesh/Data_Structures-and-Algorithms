# -*- coding: utf-8 -*-
"""
This module provides a function that randomly shuffles without
the usage of the shuffle function under the random module.
.This is the problem 2 under part B of  Exercise 1 given under
 the course UIT2201 (Programming and Data Structures).

This is a sample implementation and may contain bugs!
We have tried to follow good coding practices but don't
claim that this source code is perfect!

Your comments and suggestions are welcome.

Created on Wed Apr 05 2023

Revised on Sun Apr 09 2023

Original Author: R.Nithyasri(IT-B)[3122 22 5002 086]"""


import random
import math

# This is the function list_shuffle(seq_list)

''' The function that randomly shuffles a input list of
 integers and returns the shuffled list.
  
   Input format: A sequence (seq_list) of integers in the form of 
                 a list
                 
    Returns:    A randomly shuffled version of the input
                sequence'''

def list_shuffle(seq_list):
    length=len(seq_list)-1
    for i in range(length):
        index_1=random.randint(0,length)
        index_2=random.randint(0,length)
        seq_list[index_1],seq_list[index_2]=seq_list[index_2],seq_list[index_1]
    return seq_list

#End of the function list_shuffle(seq_list)


# This is the function random_sequence_generator

''' The function is used to generate a random sequence with N 
elements with integers in the range of a start and end 
integer, given by the user , in the form of a list 
or a tuple with N elements 

Input Format : N - number of elemetns in the sequence
               start - starting integer of the sequence
               end- end integer of the sequence
               data_type - data_type of the result(list/tuple)
               
Returns:      A randomly-generated sequence, either a list
              or a tuple'''


def random_sequence_generator(N,start,end):
    l=[]
    for i in range(N):
        element=random.randint(start,end)
        l.append(element)
    return l
    
# End of function random_sequence_generator()


# This is the main program

''' The objective is to try out multiple testcases to 
check the validity of the code'''

if __name__ == '__main__': 
    print(list_shuffle([1,6,3,4,5]))            # Sequence with integral elements
    print(list_shuffle([9.8,3.7,-1.19,5.122,-3.344,])) # Sequence with float type elements
    print(list_shuffle(['w','e','l','c','o','m','e'])) # Sequence with string-type elements
    print(list_shuffle([[9,8],[4,2],[0,9],[1,7]]))     # Sequence of nested lists

    # Testing for a randomly generated sequence

    ''' The test-case makes use of the random_sequence generator 
    function and then shuffles the random-list generated using
    the function list_shuffle.
    '''

    N=int(input("Enter the number of terms in the random list"))
    start=int(input("Enter the start value of the random range"))
    end=int(input('Enter the end value of the random range '))
    data=random_sequence_generator(N,start,end)
    print("Input List:",data)
    print("Shuffled List",list_shuffle(data)) # Testing for a random sequence




     








