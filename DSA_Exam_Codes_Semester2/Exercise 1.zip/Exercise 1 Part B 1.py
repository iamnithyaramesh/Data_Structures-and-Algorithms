# -*- coding: utf-8 -*-
"""
This module provides a function takes a sequence of 
integer values and determines if there is a distinct
pair of numbers in the sequence whose product is odd.
in the number of comparisons made for a given number of 
elements.This is the problem 1 under part B of  Exercise 1 
given under the course UIT2201 (Programming and Data Structures).

This is a sample implementation and may contain bugs!
We have tried to follow good coding practices but don't
claim that this source code is perfect!

Your comments and suggestions are welcome.

Created on Wed Apr 05 2023

Revised on Sun Apr 09 2023

Original Author: R.Nithyasri(IT-B)[3122 22 5002 086]"""

# This is the function distinct_odd_prod(list).

'''The function returns a list of distinct integers 
within a sequence  which gives a odd product when 
multiplied with one another and the number of comparisons
that are needed to considered to arrive at the solution

Input Format: A sequence of integers, taken in the 
              form of either a list or a tuple

Returns:      A sequence of tuples of  distinct integers 
              which gives a odd product
               
              The number of comparisons made within
              the sequence in order to arrive at the
              conclusion'''


def distinct_odd_prod(list):
    combination_list=[]
    for i in list:
        for j in list:
            combination_list.append((i,j))

    '''Finding the distinct integer pairs
       that yield an odd product'''

    final_list=[]
    comparisons=0
    for entry in combination_list:
        if (entry[0]%2==0 or entry[1]%2==0):
            comparisons+=1
        else:
            if entry[0]!=entry[1]:
                if (entry not in final_list) and (entry[::-1] not in final_list):
                    final_list.append(entry)
    return (final_list,comparisons)

# End of function distinct_odd_prod(list)

# This is the function testcase_random()

def testcase_random(N,start,end):
        
    ''' Input Format: The function:
                    gets the number of elements---N
                    start integer value of the  random sequence---start
                    end integer value of the random sequence---end
                    step index value(if any)---step
            
     Returns:  A random-list generated using the methods under the 
               random module.'''
    import random
    random_list=[]
    for i in range(N):
            random_list.append(random.randint(start,end))
    return random_list

# End of function testcase_random(N,start,end)

# Main Program

''' To check the validity of the function using
multiple test-cases'''

# TC-1  Executing the function for increasing values of n


if __name__ == '__main__': 
    print(distinct_odd_prod([1,3]))
    print(distinct_odd_prod([1,2]))
    print(distinct_odd_prod([3,1,8]))
    print(distinct_odd_prod([1,4,2,5]))
    print(distinct_odd_prod([7,13,4,6,2,19]))

    '''From the results, it can be observed that
    the number of comparisons made increases
    with the number of elements'''


    #TC-2 Generating for a random_list

    '''The test case involves the generation of a
    random list using the testcase_random function 
    and implementation of distinct_odd_prod on the 
    list'''

    print('\n')
    N=int(input('Enter number of entries'))
    start=int(input("Enter starting value of the random range"))
    end=int(input("Enter end value of the random range"))

    random_list=testcase_random(N,start,end)
    print(random_list)
    print(distinct_odd_prod(random_list))






        

