# -*- coding: utf-8 -*-
"""
This module provides a class function named Point Class
that initiates two Point class objects and calculates the distance
between them.This is the code of problem 1 of part A of the exercise
 2 given under the course (Programming and Data Structures).

This is a sample implementation and may contain bugs!
We have tried to follow good coding practices but don't
claim that this source code is perfect!

Your comments and suggestions are welcome.

Created on Wed Apr 05 2023

Revised on Sun Apr 23  2023

Original Author:R.Nithyasri(IT-B)[Reg No:3122 22 5002 086]
"""

# This is the class 'Point'

class Point:


    ''' The class acts on a object 'self' with two 
     data members 'a' and 'b' representing the x
    and y-coordinate of the desired point respectvely.
    
    distance(<object_1>,<object_2>) - is the member function
    of the Point class that calculates and returns the distance between
    two point objects.

    '''

    def __init__(self,a,b):
        self.x=a
        self.y=b
    def distance(obj1,obj2):
        x_comp=(obj1.x-obj2.x)**2
        y_comp=(obj1.y-obj2.y)**2
        dist=(x_comp+y_comp)**0.5
        return dist
    
#End of class definition "Point"


#Driver Code 

''' Appropriate Test Cases are to be given
to test the validity of the code'''

#Test Case 1 - Testing on positive integral values
Point_1=Point(1,2)   
Point_2=Point(2,3)
print("Distance",Point.distance(Point_1,Point_2))      # Call of the distance function under Point class

#Test Case 2 - Testing on negative integral values
Point_1=Point(-1,-4)   
Point_2=Point(-9,-2)
print("Distance",Point.distance(Point_1,Point_2))       # Call of the distance function under Point class

#Test-Case 3- Testing on positive float values
Point_1=Point(1.5,4.8)   
Point_2=Point(2.9,3.9)
print("Distance",Point.distance(Point_1,Point_2))       # Call of the distance function under Point class

#Test-Case 4- Testing on negative float values
Point_1=Point(-1.65,-4.76)   
Point_2=Point(-2.7,-3.23)
print("Distance",Point.distance(Point_1,Point_2))       # Call of the distance function under Point class

#Test-Case 5- Testing on randomly generated integral input coordinates
import random
start=int(input("Enter start value of range"))
end=int(input('Enter end value of range'))
x1=random.randint(start,end)
y1=random.randint(start,end)
x2=random.randint(start,end)
y2=random.randint(start,end)
Point_1=Point(x1,y1)   
Point_2=Point(x2,y2)
print("Distance",Point.distance(Point_1,Point_2))       # Call of the distance function under Point class