# -*- coding: utf-8 -*-
"""
This module provides a class function to generate a random sequence of n Points.
and returns k-nearest neighbours of Pnew ( k is a number and 
Pnew is the reference point) in the given sequence of n Points
This is the code of problem 2 of part A of the exercise
 2 given under the course (Programming and Data Structures).

This is a sample implementation and may contain bugs!
We have tried to follow good coding practices but don't
claim that this source code is perfect!

Your comments and suggestions are welcome.

Created on Wed Apr 05 2023

Revised on Sun Apr 23  2023

Original Author:R.Nithyasri(IT-B)[Reg No:3122 22 5002 086]
"""

# This is the class 'Point'

class Point:


    ''' The class acts on a object 'self' with two 
     data members 'a' and 'b' representing the x
    and y-coordinate of the desired point respectvely.
    
    distance(<object_1>,<object_2>) - is the member function
    of the Point class that calculates and returns the distance between
    two point objects.

    '''
    # Constructor

    def __init__(self,a,b):
        self.x=a
        self.y=b

    # End of constructor of the class

    # Defining the member function distance'

    def distance(obj1,obj2):
        x_comp=(obj1.x-obj2.x)**2
        y_comp=(obj1.y-obj2.y)**2
        dist=(x_comp+y_comp)**0.5
        return dist
    
    # End of member function 'distance


global d

# Defining the member function 'collection'

def collection(l,x,y):

    ''' The member function calculates the distance
between the given point and the reference point Pnew
and stores them in a dictionary namely 'd' with the
point object as the key and the distance as the value'''

    d={}
    for i in l:
        ref_point=Point(x,y)
        d[i]=i.distance(ref_point)
    return d

# End of member function 'collection'

# Defining the member function 'nearest_neighbours'

def nearest_neighbours(d,k):

    ''' The function takes in a dictionary input of the 
    form 'd' and an integral value of 'k'.
    The function compares the values of the dictionary
    to return the k nearest neighbours based on 
    ascending order of distances.
    '''


    l1=[]
    x=list(d.values())
    print(x)
    x.sort()
    for k in x:
            for value in d:
                if d[value]==k:
                    l1.append(value)
    return l1

    # End of member function 'nearest_neighbours'

# End of the class 'Point'


#Driver code

''' Appropriate testcases are to be given
to test the validity of the code'''

# Generating a random list of point objects

import random
n=int(input('Enter no of terms'))
start=int(input('Enter the start value of the random range'))
end=int(input('Enter the end value of the random range'))
l=[]
for i in range(n):
    x=random.randint(start,end)
    y=random.randint(start,end)
    p=Point(x,y)
    l.append(p)

#Defining the reference point Pnew

x=int(input('Enter xcoordinate of reference point'))     #Pnew=(x,y)
y=int(input("Enter ycoordinate of reference point"))
k=int(input('No of neighbours'))
L=(nearest_neighbours((collection(l,x,y)),k))
L1=[]
for x in L:
    if x not in L1:         # Checking and removal of duplicate inputs
        L1.append(x)

#Output Format
print("----------------------------------------")
print("The" ,str(k),"nearest neighbours are:")
for i in range(k):
    p=L1[i]
    print("("+str(p.x),",",str(p.y)+")")


