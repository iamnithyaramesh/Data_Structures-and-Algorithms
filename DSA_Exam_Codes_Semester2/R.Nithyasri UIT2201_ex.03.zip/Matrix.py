# -*- coding: utf-8 -*-
"""
This module provides a class function named Matrix that initiates and
performs various functions on objects of the user-defined object class.
This is the code of problem 2 of part A of the exercise
 3 given under the course (Programming and Data Structures).

This is a sample implementation and may contain bugs!
We have tried to follow good coding practices but don't
claim that this source code is perfect!

Your comments and suggestions are welcome.

Created on Wed Apr 19 2023

Revised on Fri Apr 28 2023

Original Author:R.Nithyasri(IT-B)[Reg No:3122 22 5002 086]"""

#Importing numpy module to find the determinant of the matrix
import NumPy as npy
import random

# This is the Matrix Class

class Matrix:

    ''' The class takes in a object with the row and column
     of the given matrix and performs various functions on the
      created objects of the Matrix class '''
    
    def __init__(self,row=0,column=0):

        ''' The constructor function initializes the datamembers
        with the row value of the object as 'row' and column
        value of the object as 'column'- with default values of 0
         anf initializes an empty matrix'''
        
        self.r=row
        self.c=column
        self.matrix=[]
        for i in range(row):
            l1 = [0] * column
            self.matrix.append(l1)
    

    def __getitem__(self,index):

        ''' Over-writing the __getitem__ function to obtain 
        values suing index values'''

        return self.matrix[index[0]][index[1]]
    

    def __setitem__(self,index):

        ''' Over-writing the _-setitem__ function to 
        assign mthe matrix indices to corresponding
        values'''

        val=self.matrix[index[0]][index[1]]
        return self.matrix


    def __add__(obj1,obj2):

        ''' Over-writing the _add__function for addition
        of two matrices considering same order and
        adding the values with matching indices'''

        if obj1.r!=obj2.r or obj1.c!=obj2.c: # Checking for same order
            return "Invalid!"
        else:
            result=[]
            for i in range(obj1.r):
                for j in range(obj2.c):
                    result[i][j]=obj1.matrix[i][j]+obj2.matrix[i][j]
            return result
        

    def __sub__(obj1,obj2):

        ''' Over-writing the _sub__function for subtraction
        of two matrices considering same order and
        hecnce subtracting the values with matching indices'''


        if obj1.r!=obj2.r or obj1.c!=obj2.c:    # Order Check!
            return "Invalid!"
        else:
            result=[]
            for i in range(obj1.r):
                for j in range(obj2.c):
                    result[i][j]=obj1.matrix[i][j]-obj2.matrix[i][j]
            return result
        

    def __mul__(obj1,obj2):

        ''' Over-writing the __mul__ function for multiplication
        of two matrices , (check condition = the row value of the first object 
        should be equal to the column value of the second and the column value
        of the first matrix should be equal to the row value of the second)
        '''


        if ~(obj1.r==obj2.c and obj2.r==obj1.c):
            return "Invalid"
        else:
            result=[]
            for i in range(obj1.r):
                for j in range(obj2.c):
                    for k in range(obj1.r):
                        result[i][j]+=obj1.matrix[i][k]*obj2.matrix[k][j]
        return result
    
    def determinant(self):

        ''' Using the <det> method under the <linalg> sub-module of the
        Numpy object to find the determinant of the given matrix'''


        det=npy.linalg.det(self.matrix)
        return str(det)
    
    
    def random_value_generator(self):

        ''' To generate random integral values for the entries of the matrix
        objects'''


        for i in range(self.row):
            for j in range(self.column):
                self.matrix[i][j]=random.randint(1,20)
        return self.matrix

# End of class 'Matrix'


# Driver Code

''' Appropriate Testcases are to be given to check the validity of the code'''


# Two matrices with same order(add,sub and mul possible)

Matrix_1=Matrix(3,3)
Matrix_2=Matrix(3,3)

print("Matrix_1",Matrix_1)
print("Matrix_2",Matrix_2)
print("Sum of the Matrix Objects:",Matrix_1+Matrix_2)
print("Difference of the Matrix Objects:",Matrix_1-Matrix_2)
print("Product of the Matrices:",Matrix_1*Matrix_2)
print("Determinant of the Matrix_1",Matrix.det(Matrix_1))
print('Determinant of the Matrix_2',Matrix.det(Matrix_2))
    

            
                
        



