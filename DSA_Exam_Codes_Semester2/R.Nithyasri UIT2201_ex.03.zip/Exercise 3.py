# -*- coding: utf-8 -*-
"""
This module provides a class function named Vector that initiates and
performs various functions on a user-defined object class named Vector.
This is the code of problem 1 of part A of the exercise
 3 given under the course (Programming and Data Structures).

This is a sample implementation and may contain bugs!
We have tried to follow good coding practices but don't
claim that this source code is perfect!

Your comments and suggestions are welcome.

Created on Wed Apr 19 2023

Revised on Fri Apr 28 2023

Original Author:R.Nithyasri(IT-B)[Reg No:3122 22 5002 086]


"""
# This is class 'Vector'


class Vector:

    ''' Vector class    - The class works on an object and
    value  in the form of a list/tuple. '''


    def __init__(self,val):

        ''' This is the construction function that initiates
        the object of the form self and 'value' in the
        form of a sequence'''

        self.coord=val
        self.dim=len(val)       # Dimension - length of the given input

    def __str__(self):

        ''' The __str__()function is over-rided to 
        define the print() statement for the objects
        of the Vector Class'''

        return "<"+str(self.coord)+">"  # To return the input sequence in the form of a string
    
    # Functions to facilitate iteration

    def __len__(self):

        ''' The __len__() function is over-rided to 
        facilitate iterative operations on the sequence'''

        return len(self.coord)          # Finding the length of the sequence
        
    def __getitem__(self,index):

        '''The __getitem__() function is over_rided
        to return the value corresponding to an index'''

        return (self.coord[index])      # Getting the value of a specified index
    
    def __add__(self,other):
        
        ''' The __add__ function is over-rided to work on
        two objects of the 'Vector' Class to add two matrices
        of the form 'self' and 'other'''

        l=[]
        k=0
        while k<self.dim:
            l.append(self.coord[k]+other.coord[k]) # Addition of values in a particular index to get the sum
            k=k+1
        return l
    

    def __sub__(self,other):

        ''' The __sub__ function is over-rided to work on
        two objects of the form self and other - to subtract two 
        vector objects'''

        l=[]
        k=0
        while k<self.dim:
            l.append(self.coord[k]-other.coord[k])  # Subtraction of values at a particular index
            k=k+1
        return l  
    

    def __mul__(self,other):

        '''The __mul__ function is over-rided to
        give the scalar-dot-product of two vector
         objects '''
        
        l=[]
        k=0
        while k<self.dim:
            l.append(self.coord[k]*other.coord[k])
            k=k+1
        return sum(l)   # Scalar Product -sum of the product matrix


# This is the end of the class 'Vector'

# Driver Code

''' Appropriate test cases are to be given to
check the validity of the code'''

# Test Case -1 Testing on an integral list input

V1=Vector([2,3,4])
V2=Vector([4,5,6])
print(V1+V2)
print(V1-V2)
print(V1*V2)

# Test-Case 2 Testing on an floating point tuple sequence input
print('\n')
V1=Vector((2.4,3.12,4.38))
V2=Vector((4.37,-5.21,6.95))
print(V1+V2)
print(V1-V2)
print(V1*V2)

#Test-Case 3 Testing on an random sequence of integers
print('\n')
import random
l1=[]
l2=[]
for i in range(3):
    x=random.randint(1,100)
    y=random.randint(1,100)
    l1.append(x)
    l2.append(y)
V1=Vector(l1)
V2=Vector(l2)
print(V1+V2)
print(V1-V2)
print(V1*V2)
