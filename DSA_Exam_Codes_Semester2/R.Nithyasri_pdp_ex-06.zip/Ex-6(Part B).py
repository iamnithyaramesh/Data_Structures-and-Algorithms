"""
This module provides a function that performs Quick Sort on a sequence
of elements and analyses the time complexity using emperical analysis.
This is a sample implementation and may contain bugs!
We have tried to follow good coding practices but don't
claim that this source code is perfect!

Your comments and suggestions are welcome.

Created on Mon May 21 2023

Revised on Thu May 25 2023

Original Author:R.Nithyasri(IT-B)[Reg No:3122 22 5002 086]
"""

# Fetching the required modules for execution

import random
import time
import math

# 1 This is the function 'partition'

''' The function partitions a given sequence of elements

Input: A sequence of elements,arr
       low=1
       high=len(arr)

Output: The Partition index of the sequence, i
'''
def partition(arr,low,high):
   i = low-1
   pivot = arr[high] 
   for j in range(low , high):
      if arr[j] <= pivot:
         i = i+1
         arr[i],arr[j] = arr[j],arr[i]
   arr[i+1],arr[high] = arr[high],arr[i+1]
   return i+1

# End of function 'partition'

# This is the function quickSort

def quickSort(arr,low,high):

   ''' The function does a Quick Sort- Divide and Conquer Approach
     of a given sequence by partitioning the sequence accordingly
      
       Input: A sequence of elements - seq
      
       Output: A sorted sequence of elements -sorted using Merge Sort '''
   
   if low < high:
      pi = partition(arr,low,high)
      quickSort(arr, low, pi-1)
      quickSort(arr, pi+1, high)
      return seq

# This is the function quickSort

#-----------------------------------------------------------------------------

# Driver Code

''' Appropriate testcases are to be given to test the validity of the code'''

n=int(input("Enter no of elements"))
start=int(input("Enter start value of range"))
end=int(input("Enter end value of the range"))
seq=[]
for i in range(n):                              # Getting a random list of 'n' elements
    seq.append(random.randint(start,end))

# Performing Quick Sort on the input random sequence

start_time=time.time()
print(quickSort(seq,0,len(seq)-1))
end_time=time.time()
diff=end_time-start_time
print(diff)

'''Performing Emperical Analysis on the Time Complexity'''

print("Time Complexity Analysis of Quick Sort")
print(diff/n)
print(diff/n**2)
print(diff/n**3)
print(diff/n*(math.log2(n)))


