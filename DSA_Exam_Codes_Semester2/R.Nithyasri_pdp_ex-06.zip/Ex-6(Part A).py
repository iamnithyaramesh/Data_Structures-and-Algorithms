# -*- coding: utf-8 -*-
"""
This module provides a function that performs Merge Sort on
a sequence of elements and does bnary search of a mentioned input.
This is a sample implementation and may contain bugs!
We have tried to follow good coding practices but don't
claim that this source code is perfect!

Your comments and suggestions are welcome.

Created on Mon May 21 2023

Revised on Thu May 25 2023

Original Author:R.Nithyasri(IT-B)[Reg No:3122 22 5002 086]
"""

# Fetching the required modules for execution

import random
import time
import math

# 1 This is the function 'merge'

''' The function merges two lists

Input: Two sequence of elements , l1 and l2

Output: Merged sequence of elements,l3
'''

def merge(l1,l2):
    l3=[]
    i=0
    j=0

    try:
        while True:
            if l1[i]<l2[j]:
                l3.append(l1[i])
                i+=1
            else:
                l3.append(l2[j])
                j+=1
    except IndexError:
        if i==len(l1):
            l3.extend(l2[j:])
        else:
            l3.extend(l1[i:])
    return(l3)

# End of function 'merge'

# This is the function 'merge_sort'

'''The function performs a Merge Sort on a sequence
of elements - using the Divide and Conquer Algorithm

Input: A sequence of elements ,seq

Output: A sorted sequence of elements - 
sorted by using Merge Sort Method'''

def merge_sort(seq):
    length=len(seq)
    if length==1:
        return seq
    else:
        new=length//2
        return merge(merge_sort(seq[:new]),merge_sort(seq[new:]))

#End of function 'merge-sort'

# This is the function 'binary_search'

def binary_search(seq,element):

    ''' Input: A sequence of elements,seq,an element in the seqeuecne , element
    
    The function performs a binary search of the element in the given  sequence 
    of elements.
    
    Output: The index value of the element, if found in the sequence, 
    If not found,-1'''

    low=0
    high=len(seq)
    mid=len(seq)//2
    if element==seq[mid]:
        return mid
    elif element<seq[mid]:
        for i in seq[:mid]:
            if i==element:
                return seq.index(i)
    elif element>seq[mid]:
        for j in seq[mid:]:
            if j==element:
                return seq.index(j)

# End of function 'binary-search'

#--------------------------------------------------------------------

# Driver Code 

'''Appropriate testcases are to be given to test the validity of the code'''    

n=int(input("Enter no of elements"))
start=int(input("Enter start value of range"))
end=int(input("Enter end value of the range"))
seq=[]
for i in range(n):
    seq.append(random.randint(start,end)) # Generating a random list with 'n' elements

# Merge Sort 
s_time=time.time()          
x=merge_sort(seq)
print("Sorted Sequence",x)
e_time=time.time()
search_start_time=time.time()             # To calculate the time complexity of the merge-sort algorithm


element=int(input("Enter element"))       # To do binary search of an element in the sequence
print(binary_search(x,element))
search_end_time=time.time()
f_n=e_time-s_time

print("Empirical Analysis of Time Complexity for Merge Sort")
print(f_n)
print(f_n/n)
print(f_n/(n**2))
print(f_n/(n**3))
print(f_n/(n*math.log2(n)))
f1_n=search_end_time-search_start_time

print("Empirical Analysis of Time Complexity for Binary Search")
print(f1_n)
print(f1_n/n)
print(f1_n/(n**2))
print(f1_n/(n**3))
print(f1_n/(n*math.log2(n)))

    
