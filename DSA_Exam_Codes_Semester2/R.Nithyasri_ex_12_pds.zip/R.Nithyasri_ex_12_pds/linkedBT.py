from abstractBinaryTree import AbstractBinaryTree

class LinkedBinaryTree(AbstractBinaryTree):
    '''Member Functions:
        __init__()
        root()
        parent()
        addRoot()
        __len__()
        left()
        right()
        addLeft()
        addRight()
        __str__()
        preorder()
        inorder()
        postorder()
    '''

    class BTNode:
        '''Member Functions: 
        __init__() - Constructor
        __getitem__()
        __setitem__()
        '''
        __slots__ = ['item', 'left', 'right', 'parent']

        def __init__(self, item, left=None, right=None, parent=None):
            '''This is the constructor of the class BTNode'''
            self.item = item
            self.left = left
            self.right = right
            self.parent = parent
        
        def __getitem__(self):
            '''Returns the item of a node of the tree'''
            return self.item
        
        def __setitem__(self, item):
            '''Sets the value to the item of a node'''
            self.item = item
    
    def __init__(self, item, left=None, right=None, parent=None):
        '''This is the constructor of the class LinkedBinaryTree
        Data Members: root
        '''
        super().__init__()  # Call the constructor of the base class
        self.size = 0

        if item is not None:
            '''To set the left child and right child to the root if
            defined in the initial call of the class function
            '''
            if left is not None:
                if left.root is not None:
                    left.root.parent = self.root
                    self.root.left = left.root
                    self.size += left.size
                    left.root = None
                    left.size = 0

            if right is not None:
                if right.root is not None:
                    right.root.parent = self.root
                    self.root.right = right.root
                    self.size += right.size
                    right.root = None
                    right.size = 0

    def root(self):

        ''' Returns the root of the tree'''
        return self.root
                    
    def addRoot(self, item):
        '''Assigns the root to the tree, given the item value, if not defined'''
        if self.root is not None:
            raise ValueError('Root Exists')
        self.root = self.BTNode(item)
        self.size = 1
        return self.root
    
    def left(self, pos):
        '''Returns the left child of a given node'''
        return pos.left
    
    def right(self, pos):
        '''Returns the right child of the given node'''
        return pos.right
    
    def parent(self, pos):
        '''Returns the parent of the given node'''
        return pos.parent
    
    def addLeft(self, pos, item):
        '''Adds a left child to the given node, given the item value of the left child'''
        if pos is not None:
            if self.left(pos) is not None:
                raise ValueError("Left Child Exists")
            else:
                lft_child = self.BTNode(item)
                pos.left = lft_child
                lft_child.parent = pos
            return pos.left
    
    def addRight(self, pos, item):
        '''Adds a right child to the node given the item value of the right child'''
        if pos is not None:
            if self.right(pos) is not None:
                raise ValueError("Right Child Exists")
            else:
                rgt_child = self.BTNode(item)
                pos.right = rgt_child
                rgt_child.parent = pos
            return pos.right
    
    def __str__(self):
        '''The function yields the inorder, postorder, and preorder traversal results of the tree'''
        return "Tree: " + str(list(self.inorder(self.root))) + ", " + str(list(self.preorder(self.root))) + ", " + str(list(self.postorder(self.root)))
    
    def preorder(self, pos):
        '''The function performs preorder traversal on the object'''
        if pos is None:
          return
        yield pos.item
        yield from self.preorder(pos.left)
        yield from self.preorder(pos.right)

    def inorder(self, pos):
        '''The function performs inorder traversal on the object'''
        if pos is None:
            return
        yield from self.inorder(pos.left)
        yield pos.item
        yield from self.inorder(pos.right)

    def postorder(self, pos):
        '''The function performs postorder traversal on the object'''
        if pos is None:
            return
        yield from self.postorder(pos.left)
        yield from self.postorder(pos.right)
        yield pos.item



