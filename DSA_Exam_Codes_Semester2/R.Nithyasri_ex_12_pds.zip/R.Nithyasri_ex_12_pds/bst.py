from linkedBT import LinkedBinaryTree

''' Importing LinkedBinaryTree super class from the file linkedBT file'''
class BST(LinkedBinaryTree):

    '''This class creates a binary search tree to insert and perform
    search operations
    
    Member Functions:    insert()
                         search()
                         display()'''

    def __init__(self,item=None,left=None,right=None):

        '''Invoking the constructor of the parent class'''

        super.__init__(item,left,right)
    
    def insert(self,ele,pos):

        ''' This method inserts an element in the binary tree
        
        If the element is less than the root element- the element is 
        added as the left child
        
        Or else if the element is greater than the root element - the element
        is added as the right child'''

        if pos is None:
            self.addRoot(ele)
        elif ele<pos.item:
            if pos.left is None:
                pos.left=self.addLeft(pos,ele)
            else:
                return self.addLeft(pos.left,ele)
        elif ele>pos.item:
            if pos.eight is None:
                pos.eight=self.addRight(pos,ele)
            else:
                return self.addRight(pos.left,ele)
        elif ele==pos.item:
            return 
    
    def search(self,ele,pos):

        ''' The function takes in an element and searches for it in the 
        binary tree - based on the value of the search element and returns 
        the node address of the element, if found'''

        if pos.item==ele:
            return pos
        else:
            if ele<pos.item and pos.left is not None:
                self.search(pos.left)
            elif ele>pos.item and pos.right is not None:
                self.search(pos.right)
    
    def display(self):

        ''' This method returns an inorder traversal of the
        binary search tree'''
        return self.inorder(self.root)

    