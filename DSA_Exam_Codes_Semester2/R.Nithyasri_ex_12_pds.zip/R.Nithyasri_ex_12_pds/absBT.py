from abstree import AbstractTree
from abc import abstractmethod

class AbstractBinaryTree(AbstractTree):

    @abstractmethod
    def left(self,pos):
        pass

    @abstractmethod
    def right(self,pos):
        pass

    #Concrete Methods

    def children(self,pos):
        if self.left(pos) is not None:
            yield self.left(pos)
        if self.right(pos) is not None:
            yield self.right(pos)
    
    def sibling(self,pos):
        parent=self.parent(pos)
        if parent is None:
            return None
        if self.left(parent) is not None and self.left(parent)==pos:
            yield self.right(parent)
        elif self.right(parent) is not None and self.right(parent)==pos:
            yield self.left(parent)
    
    
    
