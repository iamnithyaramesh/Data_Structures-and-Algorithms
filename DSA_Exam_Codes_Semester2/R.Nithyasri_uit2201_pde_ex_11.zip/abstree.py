from abc import ABC,abstractmethod

class AbstractTree(ABC):

    @abstractmethod
    def root(self):
        pass
    def parent(self,pos):
        pass
    def children(self,pos):
        pass
    def num_children(self,pos):
        pass
    def __len__(self):
        pass

    #Concrete Methods

    def isroot(self,pos):
        return self.root()==pos
    
    def isleaf(self,pos):
        return self.num_children(pos)==0
    
    def isempty(self):
        return len(self)==0
    
    def depthN(self,pos):
        if self.isroot(pos):
            return 0
        else:
            return 1+self.depthN(self.parent(pos))
        
    def heightN(self,pos):
        if self.isleaf(pos):
            return 0
        else:
            max=0
            for i in self.children(pos):
                height=self.heightN(i)
                if height>max:
                    max=height
            return height
    
    def height(self):
        return self.heightN(self.root())