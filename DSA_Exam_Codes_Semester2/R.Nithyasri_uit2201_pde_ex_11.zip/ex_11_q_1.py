from LinkedBinaryTree import LinkedBT

class Expression:

    def __init__(self,item=None,left=None,right=None):
        super().__init__(item,left,right)
    
    def construct(self,input_str):
        s=[]
        for ch in input_str:
            if ch not in '+-/*':
                s.append(Expression(ch))
            else:
                right_child=s.pop()
                left_child=s.pop()
                s.append(Expression(ch,left_child,right_child))
        return s.pop()
    
    def display(self):
        print(self.inorder())

E=Expression()
E.construct('ab+c-')
E.display()

