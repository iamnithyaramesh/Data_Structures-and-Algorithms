from absBT import AbstractBinaryTree

class Empty(Exception):
    pass

class LinkedBinaryTree(AbstractBinaryTree):
    
    class BTNode:

        __slots__ = ['item', 'left', 'right', 'parent']

        def __init__(self, item, left = None, right = None, parent = None) -> None:
            self.item = item
            self.left = left
            self.right = right
            self.parent = parent

        def setItem(self, item, pos):
            pos.item = item

        def getItem(self, pos):
            return pos.item
    
    def __init__(self, item = None, Tleft = None, Tright = None) -> None:
        
        __slots__ = ['root', 'size']

        self.root = None
        self.size = 0

        if item:
            self.root = self.addRoot(item)
            if Tleft and Tleft.root:
                Tleft.root.parent = self.root
                self.root.left = Tleft.root
                self.size += Tleft.size
                #delete
                Tleft.root = None
                Tleft.size = 0
            if Tright and Tright.root:
                Tright.root.parent = self.root
                self.root.right = Tright.root
                self.size += Tright.size
                #delete
                Tright.root = None
                Tright.size = 0
    
    def addRoot(self, item):
        if self.root:
            raise Empty("Root is already in the tree")
        temp = self.BTNode(item)
        self.size = 1
        return temp
    
    def addLeft(self, item, pos):
        if not pos:
            raise ValueError
        if self.left(pos):
            raise Empty("Left already exists")
        pos.left = self.BTNode(item, parent=pos)
        return pos.left
    
    def addRight(self, item, pos):
        if not pos:
            raise ValueError
        if self.right(pos):
            raise Empty("Right already exists")
        pos.right = self.BTNode(item, parent=pos)
        return pos.right
    
    def left(self, pos):
        if not pos:
            raise ValueError
        return pos.left
    
    def right(self, pos):
        if not pos:
            raise ValueError
        return pos.right
    
    def parent(self, pos):
        if not pos:
            raise ValueError
        return pos.parent
    
    def root(self):
        return self.root
    
    def __len__(self):
        return self.size
    
    def __str__(self) -> str:
        self._res = ''
        self.preorder(self.root)
        return self._res
    
    def preorder(self, pos):
        self._res += f'{pos.item} '
        if pos.left:
            self.preorder(pos.left)
        if pos.right:
            self.preorder(pos.right)
    
    def num_children(self, pos):
        count = 0
        if self.left(pos):
            count += 1
        if self.right(pos):
            count += 1
        return count
    
    def mirror(self,pos):

        if pos==None:
            return
        
        else:
            temp=pos
            self.mirror(pos.lef)
            self.mirror(pos.right)

            temp = pos.left
            pos.left = pos.right
            pos.right = temp
        
            